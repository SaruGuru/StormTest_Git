Action()
{
	web_set_max_html_param_len("999999");
	
	web_set_sockets_option("SSL_VERSION", "2&3");
	
	web_set_sockets_option("IGNORE_PREMATURE_SHUTDOWN","1");
	web_set_sockets_option("MAX_CONNECTIONS_PER_HOST", "10");
	web_set_sockets_option("INITIAL_BASIC_AUTH","0");
	web_set_max_retries("15");
	
	web_cleanup_cookies();
	
	web_cache_cleanup();
	
	web_set_sockets_option ("CLOSE_KEEPALIVE_CONNECTIONS", "1");
	web_set_sockets_option("MAX_CONNECTIONS_PER_HOST","1");

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_set_user("HPS.HPH.AD\\{pUser}", 
	"5eRm3UXk", 
		"sso.healthplan.com:443");

		 web_reg_save_param("SAML","LB=<input type=\"hidden\" name=\"SAMLResponse\" value=\"","RB=\"/>","notfound=warning",LAST);
	   
	     web_reg_save_param("session","LB=http://sso.healthplan.com/idp/","RB=/resumeSAML20/idp/startSSO.ping","notfound=warning",LAST);
	   
	lr_start_transaction("MemberKaiser_S02_CoverageDetails_T01_SSOLaunch");

	web_url("check", 
		"URL=https://pfix.servicelinkportal.com/sso/check", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		//"Url=https://sso.healthplan.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_reg_save_param("ac_id","LB=<input type=\"hidden\" name=\"ac_id\" value=\"","RB=\"/>","notfound=warning",LAST);

	web_submit_data("ACS.saml2", 
		"Action=https://sso.healthplan.com/sp/ACS.saml2", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://sso.healthplan.com/idp/{session}/resumeSAML20/idp/startSSO.ping", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=RelayState", "Value=https://pfix.servicelinkportal.com/SLP/sso", ENDITEM, 
		"Name=SAMLResponse", "Value="
		"{SAML}", ENDITEM, 
		LAST);

	web_reg_find("Text=SSO Simulation", "SaveCount=SSO",
		LAST); 
	   
	web_submit_data("sso", 
		"Action=https://pfix.servicelinkportal.com/SLP/sso", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://sso.healthplan.com/sp/ACS.saml2", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ac_id", "Value="
		"{ac_id}", ENDITEM, 
		EXTRARES, 
		//"Url=../favicon.ico", "Referer=", ENDITEM, 
		//"Url=../w1content/SiteVW/sl/images/loading.gif", "Referer=https://pfix.servicelinkportal.com/index", ENDITEM, 
		LAST);
 
	   web_reg_save_param("SAML_2","LB=<input type=\"hidden\" name=\"SAMLResponse\" value=\"","RB=\"/>","notfound=warning",LAST);
	   
	   web_reg_save_param_regexp("ParamName=opentoken","RegExp=opentoken=T1RLAQ(.*?)\\\r\\\n",SEARCH_FILTERS,"Scope=All","IgnoreRedirections=No",
		"RequestUrl=*/index.php*","Notfound=warning", LAST);

	web_submit_data("index.php", 
	 	"Action=https://pfix.servicelinkportal.com/index.php?w1=UserCTL/SSOSliderValidationCTL&task=validate_form", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/index", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=mrn", "Value={MRN}", ENDITEM, 
		"Name=DoB", "Value={DOB}", ENDITEM, 
		"Name=region", "Value=MID", ENDITEM, 
		"Name=target", "Value=https://pfix.servicelinkportal.com/XB/sso", ENDITEM, 
		"Name=resume", "Value=https://sso.healthplan.com/idp/startSSO.ping?PartnerSpId=https://sso.healthplan.com/idp_xb", ENDITEM, 
		"Name=Carrier_code", "Value=XB", ENDITEM, 
		"Name=from", "Value=xb_ssoslider", ENDITEM, 
		"Name=Login", "Value=Login", ENDITEM, 
		"Name=AC", "Value=agent-config-xb.txt", ENDITEM, 
		"Name=submit", "Value=Submit", ENDITEM, 
		LAST);

	web_reg_find("Text=\n\t\t\t\t\t\tPolicy Dashboard\t\t\t\t\t", 
		LAST);

	//<a href="/index.php?w1=BillingCTL/BillingHistoryCTL&case_num={cCase}&cim={cCim}" class="button">
	
	web_reg_save_param("cCase","LB=<a href=\"/index.php?w1=BillingCTL/BillingHistoryCTL&case_num=","RB=&","ord=1",LAST);
	
	web_reg_save_param("cCim","LB=&cim=","RB=\" class=\"button\">","ord=1",LAST);

	web_submit_data("ACS.saml2_2", 
		"Action=https://sso.healthplan.com/sp/ACS.saml2", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://sso.healthplan.com/idp/startSSO.ping?PartnerSpId=https://sso.healthplan.com/idp_xb&TARGET=https://pfix.servicelinkportal.com/XB/sso&opentoken=T1RLAQ{opentoken}", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=RelayState", "Value=https://pfix.servicelinkportal.com/XB/sso", ENDITEM, 
		"Name=SAMLResponse", "Value="
		"{SAML_2}", ENDITEM, 
		EXTRARES, 
		/*"Url=https://www.google-analytics.com/analytics.js", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j79&a=318552265&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=1030579144&gjid=1681015867&cid=1838330568.1510566558&tid=UA-132564258-1&_gid=1621410167.1579695605&_r=1&cd1=kp%2Fmember&z=1759892938", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j79&a=318552265&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=436641956&gjid=1911660536&cid=1838330568.1510566558&tid=UA-132564258-39&_gid=1621410167.1579695605&_r=1&cd1=kp%2Fmember&z=220267546", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j79&a=318552265&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=1035497056&gjid=1173540006&cid=1838330568.1510566558&tid=UA-132564258-3&_gid=1621410167.1579695605&_r=1&cd1=kp%2Fmember&z=1818084686", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=318552265&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-1&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=27612332", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/r/collect?v=1&_v=j79&a=318552265&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=2074360135&gjid=808153811&cid=1838330568.1510566558&tid=UA-132564258-37&_gid=1621410167.1579695605&_r=1&cd1=kp%2Fmember&z=1974914615", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=318552265&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-39&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1419313770", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=318552265&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-3&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=2001795546", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=318552265&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2F&dr="
		"https%3A%2F%2Fsso.healthplan.com%2Fidp%2FstartSSO.ping%3FPartnerSpId%3Dhttps%3A%2F%2Fsso.healthplan.com%2Fidp_xb%26TARGET%3Dhttps%3A%2F%2Fpfix.servicelinkportal.com%2FXB%2Fsso%26opentoken%3DT1RLAQBp4nT8RMnAJwIZ5DEZ4Fop8EX4wQAAALR4nGWOuwrCQBBF-_2XldkxKgYGBG0s7KxsZKMTXUlmZDNB_XsfCCqWh3O43NjbUeYqxlej-AWO25gaMu4szM5JDmnPYslug522XxL_ZZuFQoEwDmN8wvacuU5XcvtorHWVsh0JJh7Qh-mkcJkPSYVWy4VrYmcSWybX9dWJd0YnZSdqvuJaMxMCgofgEdcBy9G0DLB5eRWv2cfaOP9EwxKKV5RZ-OL7x83mEwzXAO-VO5cKVgE*&ul=en-us&de=utf-8&dt="
		"Policy%20Dashboard&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-37&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1210863998", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://pfix.servicelinkportal.com/w1content/SiteVW/sl/images/XB_DEFAULT.png", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://pfix.servicelinkportal.com/w1content/SiteVW/sl/member/images/left-circular-10.png", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://pfix.servicelinkportal.com/w1content/SiteVW/sl/images/scroll-top-arrow.png", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://pfix.servicelinkportal.com/w1content/SiteVW/sl/images/accordion-blue-closed.png", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://pfix.servicelinkportal.com/w1content/SiteVW/sl/images/accordion-blue-opened.png", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		"Url=https://pfix.servicelinkportal.com/w1content/SiteVW/sl/images/accordion-closed.png", "Referer=https://pfix.servicelinkportal.com/", ENDITEM, 
		*/LAST);
	
	// lr_end_transaction("MemberKaiser_S02_CoverageDetails_T01_SSOLaunch", LR_AUTO);
	 
	 if(atoi(lr_eval_string("{SSO}"))>0)
				{
			
			lr_end_transaction("MemberKaiser_S02_CoverageDetails_T01_SSOLaunch",LR_PASS);
		}
		else
		{
			
			lr_error_message("MemberKaiser_S02_CoverageDetails_T01_SSOLaunch  is not loaded for Iteration: %s, Username: %s, ClockTime: %s", lr_eval_string("{Iter}"), lr_eval_string("{pUser}"),lr_eval_string("{TimeStamp}"));
			lr_end_transaction("MemberKaiser_S02_CoverageDetails_T01_SSOLaunch",LR_FAIL);
			
		}
	
	
	 lr_think_time(10);

	  lr_start_transaction("MemberKaiser_S02_CoverageDetails_T02_ClickSubmitButton");
	
	web_url("index.php_2", 
		"URL=https://pfix.servicelinkportal.com/index.php?w1=CaseCTL/CaseSearchCTL&no_html=true&task=render_caseinfo_section&case_num={cCase}&cim_num={cCim}&_=1579697961279", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("index.php_3", 
		"URL=https://pfix.servicelinkportal.com/index.php?w1=CaseCTL/CaseSearchCTL&no_html=true&task=render_agent_section&case_num={cCase}&cim_num={cCim}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("index.php_4", 
		"URL=https://pfix.servicelinkportal.com/index.php?w1=CaseCTL/CaseSearchCTL&no_html=true&task=render_coverage_section&case_num={cCase}&cim_num={cCim}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("index.php_5", 
		"URL=https://pfix.servicelinkportal.com/index.php?w1=CaseCTL/CaseSearchCTL&no_html=true&task=render_billing_section&case_num={cCase}&cim_num={cCim}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("MemberKaiser_S02_CoverageDetails_T02_ClickSubmitButton",LR_AUTO);
	
	lr_think_time(10);

	lr_start_transaction("MemberKaiser_S02_CoverageDetails_T03_CoverageDetails");
	
	web_reg_find("Text=\n\t\t\t\t\t\tCoverage\t\t\t\t\t","SaveCount=Coverage",
		LAST);

	web_url("coverage", 
		"URL=https://pfix.servicelinkportal.com/Coverage/coverage", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		/*"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-1&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1188878228", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-39&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1827828826", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-3&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=563827280", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-37&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=2098035540", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-1&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1667064394", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-39&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=882010471", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-3&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=414660827", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=1950784909&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2FCoverage%2Fcoverage&ul=en-us&de=utf-8&dt=Coverage&sd=24-bit&sr=1366x768&vp=1349x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-37&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=835075453", ENDITEM, 
		*/LAST);

	//lr_end_transaction("MemberKaiser_S02_CoverageDetails_T03_CoverageDetails",LR_AUTO);
	if(atoi(lr_eval_string("{Coverage}"))>0)
				{
			
			lr_end_transaction("MemberKaiser_S02_CoverageDetails_T03_CoverageDetails",LR_PASS);
		}
		else
		{
			
			lr_error_message("CoverageDetails  is not loaded for {Iter}ation%s, Username%s, ClockTime:%s", lr_eval_string("{Iter}"), lr_eval_string("{pUser}"),lr_eval_string("{TimeStamp}"));
			lr_end_transaction("MemberKaiser_S02_CoverageDetails_T03_CoverageDetails",LR_FAIL);
			
		}
	
	lr_think_time(10);

	lr_start_transaction("MemberKaiser_S02_CoverageDetails_T04_ClickLogoutButton");

	web_reg_find("Text=\n\t\t\t\t\t\tlogged-out\t\t\t\t\t", 
		LAST);

	web_url("LogoutClick here to sign out", 
		"URL=https://pfix.servicelinkportal.com/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://pfix.servicelinkportal.com/Coverage/coverage", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		/*"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-39&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1186917468", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-1&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1786570916", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-39&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=89144094", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-1&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1135631982", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-37&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1580467819", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=1&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-3&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=211357553", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-3&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1566760169", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j79&a=604070558&t=pageview&_s=2&dl=https%3A%2F%2Fpfix.servicelinkportal.com%2Flogout&ul=en-us&de=utf-8&dt=logged-out&sd=24-bit&sr=1366x768&vp=1366x652&je=1&_u=AACAAEQ~&jid=&gjid=&cid=1838330568.1510566558&tid=UA-132564258-37&_gid=1621410167.1579695605&cd1=kp%2Fmember&z=1743888572", ENDITEM, 
		*/LAST);

	lr_end_transaction("MemberKaiser_S02_CoverageDetails_T04_ClickLogoutButton",LR_AUTO);
	
	return 0;
}
